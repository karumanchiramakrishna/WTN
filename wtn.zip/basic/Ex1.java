package com.languagebasics;

public class Ex1 {

	public static void main(String[] args);
    System.out.print(args[0]+ " Technologies " +args[1]);
	}

}
