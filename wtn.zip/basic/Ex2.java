package com.languagebasics;

public class Ex2 {

	public static void main(String[] args) {
		
System.out.println(args[0]+" Tecnologies "+args[1]);
	}

}
