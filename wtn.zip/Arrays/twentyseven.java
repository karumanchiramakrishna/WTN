class twentyseven
{
	public static void main(String[] args) {
		int[] a ={5,6,8,4,3,4,58,65,120,94,103};
		int firstmax=a[0],secondmax=a[0],firstmin=a[0],secondmin=a[0];
		for(int i=1;i<a.length;i++)
		{
			if(a[i]>firstmax)
			{
				secondmax=firstmax;
				firstmax=a[i];
			}
			else if(a[i]<firstmax && a[i]>secondmax)
				secondmax=a[i];
			if(a[i]<firstmin)
			{
				secondmin=firstmin;
				firstmin=a[i];
			}
			else if(a[i]>firstmin && a[i]<secondmin)
				secondmin=a[i];
		}
		System.out.println("first maximum is "+firstmax+"\nsecond maximum is "+secondmax);
		System.out.print("first minimum is "+firstmin+"\nsecond minimum is "+secondmin);
	}
}