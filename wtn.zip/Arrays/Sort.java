import java.util.*;
class Sort
{
	public static void main(String[] args) {
		int a[]={5,6,8,4,3,4,58,65,120,94,103,120};
		Arrays.sort(a);
		int f=0;
		for(int i=0;i<a.length-1;i++)
		{
			if(a[i]!=a[i+1])
				a[f++]=a[i];
		}
		a[f]=a[a.length-1];
		for(int i=0;i<=f;i++)
		{
			System.out.print(a[i]+" ");
		}
	}
}