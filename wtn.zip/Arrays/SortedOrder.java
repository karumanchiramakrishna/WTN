import java.util.*;
class SortedOrder
{
	public static void main(String[] args) {
		int a[]={5,6,8,4,3,4,58,65,120,94,103};
		Arrays.sort(a);
		for (int i :a)
		{
			System.out.print(i+" ");
		}
	}
}