import java.util.*;
class P30
{
	public static void main(String[] args) {
		Scanner s= new Scanner(System.in);
		int n=s.nextInt();
		int [] a= new int[n];
		for(int i=0;i<n;i++)
			a[i]=s.nextInt();
		int sum=0,sum67=0,i6=0,i7=0;
		for(int i=0;i<n;i++)
		{
			if(i6==1){
				sum67+=a[i];
				continue;
			}
			if(a[i]==6){
				i6=1;
				continue;
			}
			if(a[i]==7 && i6==1)
			{
				sum67=0;
				i6=0;
				continue;
			}
			sum+=a[i];

		}
		if(i6==1)
			sum+=sum67+6;
		System.out.println("sum is "+sum);
	}
}