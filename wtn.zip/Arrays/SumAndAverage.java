class SumAndAverage
{
	public static void main(String[] args) {
		int[] a = {1,2,3,4,5,6};
		int sum=0,avg=0;
		for(int i=0;i<a.length;i++)
			sum+=a[i];
		avg=sum/a.length;
		System.out.println("Sum is "+sum+"\naverage is "+avg);
	}
}