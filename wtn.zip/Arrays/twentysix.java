class twentysix
{
	public static void main(String[] args) {
		int[] a = {97,40,8,65,120,48,33,56};
		for(int i=0;i<a.length;i++)
		{
			System.out.print((char)a[i]+" ");
		}
	}
}