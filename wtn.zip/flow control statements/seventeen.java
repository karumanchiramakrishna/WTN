class seventeen
{
	public static void main(String[] args) {
		if(args.length!=1 || args[0].matches("^[0-9]+$")==false)
		{
			System.out.println("Please enter an integer");
			System.exit(0);
		}
		int n=Integer.parseInt(args[0]);
		int x=0,p=1;
		while(n!=0)
		{
			x*=10;
			x+=n%10;
			n/=10;
		}
		System.out.println(x);
	}
}