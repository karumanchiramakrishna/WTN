class seven
{
public static void main(String args[])
{
if(args.length!=1 || args[0].length()!=1)
{
System.out.println("Give correct inputs");
System.exit(0);
}
char a=args[0].charAt(0);
if(Character.isUpperCase(a))
System.out.println(a+"->"+Character.toLowerCase(a));
else
System.out.println(a+"->"+Character.toUpperCase(a));
}
}