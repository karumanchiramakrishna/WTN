import java.util.regex.*;
class fifteen
{
	public static void main(String[] args) {
		if(args.length!=1 || args[0].matches("^[0-9]+$")==false)
		{
			System.out.println("Please enter an integer");
			System.exit(0);
		}
		int count=0;
		for(int i=0;i<args[0].length();i++)
		{
			count+=Integer.parseInt(String.valueOf(args[0].charAt(i)));
		}
		System.out.println(count);
	}
}