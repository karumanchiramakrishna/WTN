class fourteen
{
	public static void main(String[] args) {
		if(args.length!=1)
		{
			System.out.println("Please enter an integer");
			System.exit(0);
		}
		int a=Integer.parseInt(args[0]);
		if(a==1 ||a==0)
		{
			System.out.println(a +" is neither prime nor composite");
			System.exit(0);
		}
		for(int i=2;i<=Math.sqrt(a);i++)
		{
			if(a%i==0)
			{
				System.out.println(a+" is Not a Prime");
				System.exit(0);
			}
		}
		System.out.println(a+" is a Prime Number");
	}
}