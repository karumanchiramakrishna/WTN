class Order
{
public static void main(String args[])
{
if(args.length!=2 ||args[0].length()!=1 ||args[1].length()!=1)
{
System.out.println("Give a character input");
System.exit(0);
}
char a=args[0].charAt(0);
char b=args[1].charAt(0);
if(a>b)
System.out.println(b+","+a);
else
System.out.println(a+","+b);
}
}