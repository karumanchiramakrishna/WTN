import java.util.regex.*;
class five
{
public static void main(String args[])
{
if(args.length!=1||args[0].length()!=1)
{
System.out.println("Give a correct input");
System.exit(0);
}
if(args[0].matches("^[a-zA-Z]$"))
System.out.print("Alpha");
else if(args[0].matches("^[0-9]$"))
System.out.print("Digit");
else
System.out.print("Special character");


}
}