class Evenorodd
{
public static void main(String args[]){
int a=Integer.parseInt(args[0]);
if(a>0)
System.out.println(a+" is a positive number");
if(a<0)
System.out.println(a+" is a negative number");
else
System.out.println("0 is neither negative or positive");
}
}
}