class one	
{
public static void main(String args[])
{
if(args.length==0)
{
System.out.println("No Values");
System.exit(0);
}
for(int i=0;i<args.length;i++)
System.out.print(args[i]+" ");
}
}