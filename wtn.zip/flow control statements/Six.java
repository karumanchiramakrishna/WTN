public class Main{
    public static void main(String[] args){
       String gender = String.parseString(args[0]);
           int age=Integer.parseInt(args[1]);
           if(gender==female&& 1<=age<=58){
               System.out.println("the percentage of interest is 8.2%");
           }
               else if(gender==female&& 59<=age<=100){
                   System.out.println("the percentage of interest is 9.2%");
               }
               else if(gender==male&& 1<=age<=58){
                System.out.println("the percentage of interest is 8.4%");
}
                 else if(gender==male&& 59<=age<=100){
                System.out.println("the percentage of interest is 10.5%");
 
                 }  
    }
}